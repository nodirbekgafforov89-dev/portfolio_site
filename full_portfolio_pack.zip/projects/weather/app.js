const form = document.getElementById('cityForm');
const cityInput = document.getElementById('city');
const out = document.getElementById('result');

async function geocodeCity(name){
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=uz&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Geocoding error');
  const data = await res.json();
  if (!data.results || !data.results.length) throw new Error('Shahar topilmadi');
  const { latitude, longitude, name: cityName, country } = data.results[0];
  return { latitude, longitude, cityName, country };
}

async function fetchWeather(lat, lon){
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&daily=temperature_2m_max,temperature_2m_min&timezone=auto`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Weather error');
  return res.json();
}

function render(data, info){
  const cur = data.current_weather;
  const d = data.daily;
  out.innerHTML = `
    <h2>${info.cityName}, ${info.country}</h2>
    <p><b>Hozir:</b> ${cur.temperature}°C, shamol ${cur.windspeed} km/soat</p>
    <p><b>Ertangi min/max:</b> ${d.temperature_2m_min[1]}°C / ${d.temperature_2m_max[1]}°C</p>
  `;
}

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const q = cityInput.value.trim();
  if (!q) return;
  out.textContent = 'Yuklanmoqda...';
  try{
    const info = await geocodeCity(q);
    const weather = await fetchWeather(info.latitude, info.longitude);
    render(weather, info);
  }catch(err){
    out.textContent = err.message || 'Xatolik';
  }
});
