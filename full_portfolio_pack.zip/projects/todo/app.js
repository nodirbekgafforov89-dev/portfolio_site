const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const form = $('#todoForm');
const input = $('#todoInput');
const list = $('#list');
const empty = $('#empty');
const search = $('#search');
const filter = $('#filter');
const clearAll = $('#clearAll');
let todos = JSON.parse(localStorage.getItem('todos') || '[]');
function save(){ localStorage.setItem('todos', JSON.stringify(todos)); }
function render(){
  list.innerHTML = '';
  const q = (search.value || '').toLowerCase();
  const f = filter.value;
  const filtered = todos.filter(t => {
    const byQuery = t.text.toLowerCase().includes(q);
    const byFilter = f==='all' ? true : f==='done' ? t.done : !t.done;
    return byQuery && byFilter;
  });
  filtered.forEach(t => {
    const li = document.createElement('li');
    if (t.done) li.classList.add('done');
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = t.done;
    cb.addEventListener('change', () => { t.done = cb.checked; save(); render(); });
    const txt = document.createElement('span');
    txt.className = 'text'; txt.textContent = t.text; txt.contentEditable = false;
    const actions = document.createElement('div'); actions.className = 'actions';
    const editBtn = document.createElement('button'); editBtn.textContent = '✏️'; editBtn.title='Tahrirlash';
    editBtn.addEventListener('click', () => {
      if (txt.isContentEditable){ t.text = txt.textContent.trim(); txt.contentEditable=false; editBtn.textContent='✏️'; save(); render(); }
      else { txt.contentEditable=true; txt.focus(); editBtn.textContent='✅'; }
    });
    const delBtn = document.createElement('button'); delBtn.textContent='🗑️'; delBtn.title='O‘chirish';
    delBtn.addEventListener('click', () => { todos = todos.filter(x => x.id !== t.id); save(); render(); });
    actions.append(editBtn, delBtn);
    li.append(cb, txt, actions); list.append(li);
  });
  empty.style.display = todos.length ? 'none' : 'block';
}
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  todos.unshift({ id: Date.now(), text, done:false });
  input.value = ''; save(); render();
});
search.addEventListener('input', render);
filter.addEventListener('change', render);
clearAll.addEventListener('click', () => { if (confirm('Barcha vazifalarni o‘chirilsinmi?')){ todos = []; save(); render(); } });
render();
